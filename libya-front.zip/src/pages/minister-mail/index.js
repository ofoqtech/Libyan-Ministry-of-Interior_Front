export { MinisterMail } from './MinisterMail';
